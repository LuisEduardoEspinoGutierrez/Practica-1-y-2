package com.upiiz.Practica1_2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Practica12ApplicationTests {

	@Test
	void contextLoads() {
	}

}
