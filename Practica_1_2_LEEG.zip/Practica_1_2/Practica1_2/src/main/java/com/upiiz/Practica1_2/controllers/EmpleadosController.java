package com.upiiz.Practica1_2.controllers;

import com.upiiz.Practica1_2.models.Empleado;
import com.upiiz.Practica1_2.services.EmpleadosService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;


@Controller
public class EmpleadosController {
    //Mostrar el listado
    EmpleadosService empleadoService = new EmpleadosService();
    @GetMapping("/empleados")
    public String empleados(Model model) {
        model.addAttribute("empleados", empleadoService.findAll());
        return "listado-empleados";
    }
    //Guardar una empleado
    @GetMapping("/empleados/agregar")
    //1. Mostar el formulario
    public String nuevoEmpleadoFormulario(Model model) {
        Empleado empleado = new Empleado();
        model.addAttribute("empleado", empleado);
        return "empleados-agregar";
    }
    //2. Guardar un empleado y redireccionar al listado
    @PostMapping("/empleados/agregar")
    public String nuevoEmpleadoAgregar(@ModelAttribute("empleado") Empleado empleado)
    {
        empleadoService.save(empleado);
        return "redirect:/empleados";
    }

    //Eliminar un empleado
    // 1. Mostrar empleado en el formulario
    @GetMapping("/empleados/eliminar/{id}")
    public String eliminarEmpleadoFormulario(@PathVariable int id, Model model)
    {
        Empleado empleado = empleadoService.getEmpleado(id);
        if (empleado != null)
        {
            model.addAttribute("empleado", empleado);
            return "empleados-eliminar";
        }
        else
            return "empleados-eliminar";
    }
    // 2. Eliminar el empleado y redireccionar al listado
    @PostMapping("/empleados/eliminar")
    public String eliminarEmpleado(@ModelAttribute("empleado") Empleado empleado)
    {
        System.out.println("eliminando empleado: " + empleado.getId());
        empleadoService.delete(empleado.getId());
        return "redirect:/empleados";
    }

    //Actualizar un empleado
    //1. Mostrar el formulario para actualizar
    @GetMapping("/empleados/actualizar/{id}")
    public String actualizarEmpleadoFormulario(@PathVariable int id, Model model)
    {
        Empleado empleado = empleadoService.getEmpleado(id);
        if (empleado != null)
        {
            model.addAttribute("empleado", empleado);
            return "empleados-actualizar";
        }
        else return "redirect:/empleados";

    }

    //2. Actualizar y redireccionar al listado
    @PostMapping("/empleados/actualizar")
    public String actualizarEmpleado(@ModelAttribute("empleado") Empleado empleado)
    {
        empleadoService.update(empleado);
        return "redirect:/empleados";
    }





}
