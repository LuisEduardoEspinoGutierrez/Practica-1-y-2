package com.upiiz.Practica1_2.repositories;

import com.upiiz.Practica1_2.models.Empleado;
import com.upiiz.Practica1_2.models.Empleado;

import java.util.List;

public interface EmpleadosRepository {

    //Regrese todos los usuarios
    public List<Empleado> findAll();
    //Regrese un Empleado por id
    public Empleado getEmpleado(int id);
    //agregar un Empleado
    public void save(Empleado empleado);
    //eliminar  un Empleado
    public void delete(int id);
    //actualizar un Empleado
    public void update(Empleado Empleado);
}
