package com.upiiz.Practica1_2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Practica12Application {

	public static void main(String[] args) {
		SpringApplication.run(Practica12Application.class, args);
	}

}
