package com.upiiz.Practica1_2.services;

//Extends - Herencia - Heredar las propiedades de otra clase
//Implementsn - Usar o implementar los metodos de otra case

import com.upiiz.Practica1_2.models.Usuario;
import com.upiiz.Practica1_2.repositories.UsuariosRepository;

import java.util.ArrayList;
import java.util.List;

public class UsuariosService implements UsuariosRepository{
    //Requerimos
    //1. acceso a una base de datos - Aun no

    //2. Acceso a un listado en memoria

    private List<Usuario> usuarios;
    private int lastId = 0;

    public UsuariosService() {
        //Evitar en NULL pointer excpetion
        usuarios = new ArrayList<>();
        usuarios.add(new Usuario(1, "luis", "luis@gmail.com", "luis123"));
        usuarios.add(new Usuario(2, "david", "david@gmail.com", "david123"));
        lastId = 3;
    }

    @Override
    public List<Usuario> findAll() {
        return usuarios;
    }

    @Override
    public Usuario getUsuario(int id) {
        return usuarios.stream().filter(m -> m.getId() == id).findFirst().orElse(null);
    }

    @Override
    public void save(Usuario usuario) {
        lastId++;
        usuario.setId(usuarios.size() + 1);
        usuarios.add(usuario);
    }

    @Override
    public void delete(int id) {
        usuarios.removeIf(m -> m.getId() == id);
    }

    @Override
    public void update(Usuario usuario) {
        //es por referencia
        Usuario m = getUsuario(usuario.getId());
        m.setNombre(usuario.getNombre());
        m.setCorreo(usuario.getCorreo());
        m.setContrasena(usuario.getContrasena());
    }

    //para obtener el usuario por correo
    @Override
    public Usuario getUsuarioPorCorreo(String correo) {
        return usuarios.stream()
                .filter(u -> u.getCorreo().equalsIgnoreCase(correo))
                .findFirst()
                .orElse(null);
    }

}
