package com.upiiz.Practica1_2.services;

import com.upiiz.Practica1_2.models.Empleado;
import com.upiiz.Practica1_2.repositories.EmpleadosRepository;


import java.util.ArrayList;
import java.util.List;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;


public class EmpleadosService implements EmpleadosRepository{

    private List<Empleado> empleados;
    private int lastId = 0;

    public EmpleadosService()
    {
        empleados= new ArrayList<>();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        empleados.add(new Empleado(1, "Gael", "Ingeniero", 30000,  LocalDate.parse("22/08/2025", formatter)));
        empleados.add(new Empleado(2, "Fernando", "Sonido", 35000,  LocalDate.parse("20/08/2025", formatter)));
        lastId=3;
    }

    @Override
    public List<Empleado> findAll() {
        return empleados;
    }

    @Override
    public Empleado getEmpleado(int id) {

        return empleados.stream().filter(m -> m.getId() == id).findFirst().orElse(null);

    }

    @Override
    public void save(Empleado empleado) {
        lastId++;
        empleado.setId(empleados.size()+1);
        empleados.add(empleado);
    }

    @Override
    public void delete(int id) {
        empleados.removeIf(m -> m.getId() == id);
    }

    @Override
    public void update(Empleado empleado) {
        //Es por referencia
        Empleado m = getEmpleado(empleado.getId());
        m.setNombre(empleado.getNombre());
        m.setPuesto(empleado.getPuesto());
        m.setSalario(empleado.getSalario());
        m.setFechaContratacion(empleado.getFechaContratacion());

    }


}

