package com.upiiz.Practica1_2.controllers;

import com.upiiz.Practica1_2.models.Usuario;
import com.upiiz.Practica1_2.services.EmpleadosService;
import com.upiiz.Practica1_2.services.UsuariosService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import jakarta.servlet.http.HttpSession;

@Controller
public class UsuariosController {

   //mostrar el listado
   UsuariosService usuarioService = new UsuariosService();
   @GetMapping("/usuarios")
    public String usuarios(Model model){
       model.addAttribute("usuarios", usuarioService.findAll());
       return "index";

   }

   //Guardar un usuario
    @GetMapping("/usuarios/agregar")
    //1.mostrar el formulario
    public String nuevoUsuarioFormulario(Model model)
    {
        Usuario usuario = new Usuario();
        model.addAttribute("usuario", usuario);
        return "pages-sign-up";
    }

    //2. Guardar el usuario y redireccionar al listado
    @PostMapping("/usuarios/agregar")
    public String nuevoUsuarioAgregar(@ModelAttribute("usuario") Usuario usuario)
    {
        usuarioService.save(usuario);
        return "redirect:/usuarios";
    }

    //eliminar un usuario
    //1.mostrar usuario en el formulario

    @GetMapping("/usuarios/eliminar/{id}")
    public String eliminarUsuarioFormulario(@PathVariable int id, Model model)
    {
        Usuario usuario = usuarioService.getUsuario(id);
        if (usuario != null)
        {
            model.addAttribute("usuario", usuario);
            return "usuarios-eliminar";
        }
        else
            return "usuarios-eliminar";
    }
    // 2. Eliminar el usuario y redireccionar al listado
    @PostMapping("/usuarios/eliminar")
    public String eliminarUsuario(@ModelAttribute("usuario") Usuario usuario)
    {
        System.out.println("eliminando usuario: " + usuario.getId());
        usuarioService.delete(usuario.getId());
        return "redirect:/usuarios";
    }

    //Actualizar un usuario
    //1. Mostrar el formulario para actualizar
    @GetMapping("/usuarios/actualizar/{id}")
    public String actualizarUsuariosFormulario(@PathVariable int id, Model model)
    {
        Usuario usuario = usuarioService.getUsuario(id);
        if (usuario != null)
        {
            model.addAttribute("usuario", usuario);
            return "usuarios-actualizar";
        }
        else return "redirect:/usuarios";

    }
    //2. Actualizar y redireccionar al listado
    @PostMapping("/usuarios/actualizar")
    public String actualizarUsuario(@ModelAttribute("usuario") Usuario usuario)
    {
        usuarioService.update(usuario);
        return "redirect:/usuarios";
    }

    //mostrar el formulario de login
    @GetMapping("/usuarios/login")
    public String mostrarLogin(Model model) {
        model.addAttribute("usuario", new Usuario());
        return "pages-sign-in"; // Vista HTML del login
    }


    //procesar el login
    @PostMapping("/usuarios/login")
    public String loginUsuario(@ModelAttribute("usuario") Usuario usuario, HttpSession session, Model model) {
        Usuario encontrado = usuarioService.getUsuarioPorCorreo(usuario.getCorreo());

        if (encontrado != null && encontrado.getContrasena().equals(usuario.getContrasena())) {
            session.setAttribute("usuarioActual", encontrado);
            return "redirect:/usuarios"; // redirige al listado si el login es correcto
        } else {
            model.addAttribute("error", "Correo o contraseña incorrectos");
            return "pages-sign-in"; // vuelve al login si falla
        }
    }

    //Cerrar sesion
    @GetMapping("/logout")
    public String cerrarSesion(HttpSession session) {
        session.invalidate();
        return "redirect:/usuarios/login";
    }


}







