package com.upiiz.Practica1_2.models;

import org.attoparser.trace.MarkupTraceEvent;
import java.time.LocalDate;

public class Empleado {
    private int id;
    private String  nombre;
    private String puesto;
    private int salario;
    private LocalDate fecha_contratacion;

    public Empleado(int id,String nombre, String puesto, int salario, LocalDate fecha_contratacion)
    {
        this.id=id;
        this.nombre=nombre;
        this.puesto=puesto;
        this.salario=salario;
        this.fecha_contratacion=fecha_contratacion;
    }
    public Empleado()
    {

    }

    public void setId(int id) {
        this.id = id;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setPuesto(String puesto) {
        this.puesto = puesto;
    }

    public void setSalario(int salario) {
        this.salario = salario;
    }

    public void setFechaContratacion(LocalDate fecha_contratacion) {
        this.fecha_contratacion = fecha_contratacion;
    }


    public int getId(){return id;}

    public String getNombre(){return nombre;}

    public String getPuesto(){return puesto;}

    public int getSalario(){return salario;}

    public LocalDate getFechaContratacion(){return fecha_contratacion;}



}
